<?php
// controllers/HomeController.php

require_once 'models/Slide.php';
require_once 'models/Service.php';
require_once 'models/Testimonial.php';
require_once 'models/BackgroundImage.php';
require_once 'models/servicios.php'; 
require_once 'models/Galeria.php'; 

class HomeController {
    public function index() {
        $slides = Slide::getActiveSlides();
        $services = Service::getServices();
        $testimonials = Testimonial::getActiveTestimonials();
        $backgroundImages = BackgroundImage::getAll();
        
        $categorias = Blog::getCategorias();
        foreach ($categorias as &$cat){
            $cat['articulos'] = Blog::getTopArticulosByCategoria($cat['idcat']);
        }
        unset($cat);

        // --- CONSULTA EL SERVICIO 'home' Y SUS DETALLES ---
        $servicioHome = Servicios::getServicioBySlug('home');
        $detallesHome = [];
        if ($servicioHome) {
            $detallesHome = Servicios::getDetallesByServicio($servicioHome['idser']);
        }

        // Carrusel de galerias
        $categorias = Galeria::getCategorias();
        $galeriaPorCategoria = [];

        foreach ($categorias as $cat) {
            $galeriaPorCategoria[$cat['idcat']] = Galeria::getImagenesPorCategoria($cat['idcat']);
        }

        // 2) Incluir la vista, pasando estos datos
        require_once 'views/home/index.php';
    }
}
