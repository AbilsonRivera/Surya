<?php
class DermatologiaController {
    public function index() {
        require_once 'views/dermatologia/index.php'; // O la vista que desees
    }
}
