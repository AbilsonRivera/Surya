<div class="form-section" id="zonaformulario">
  <div class="form-container">
    <img src="/img/banner/transforma-surya.jpg" alt="Logo alma" width="250" height="auto">
  </div>

  <div class="info-container">
    <h2 class="form_tiltulo">Empieza tu </h2><span class="form_tilt">transformación</span>
    <p class="form_text">
      Nuestro propósito es facilitar el camino de conexión con esa energía vital a través de tres caminos.
    </p>
    <a href="/alma" class="btn btn-agendar">Ver Clases</a>
  </div>
</div>

