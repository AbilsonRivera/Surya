<div class="col-sm-12 col-md-6">
    <h4>Términos y condiciones de las membresías:</h4>
    <p>
        <ol>
            <li>Las clases tienen una duración de 1 hora.</li>
            <li>Todas las membresías presenciales tienen un lapso de 37 días para ser usadas. No hay congelaciones de planes.</li>
            <li>Los invitados pueden asistir una única vez en calidad de invitado.</li>
            <li>Se pueden realizar transferencias de paquetes con autorización del tomador del mismo.</li>
            <li>No se realizan devoluciones de dinero luego de haber realizado el pago de la membresía o servicio.</li>
            <li>Para asistir a las clases deben agendarse a tavés de la web. Se puede agendar si hay espacio hasta útimo minuto antes de iniciar la clase.</li>
            <li>Si la clase no es cancelada con mínimo 5 horas de anticipación la clase se da por tomada.</li>
            <li>Todos los asistentes regulares deben tomar al menos una vez una clase de inducción.</li>
            <li style="color: red;">Quienes paguen paquete presencial y no puedan asistir a su clase presencial pueden tomarla virtual.</li>
        </ol>
    </p>
</div>